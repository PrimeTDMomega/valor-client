package me.earth.earthhack.impl.event.events.movement;

public class HorseEvent
{
    private double jumpHeight;

    public void setJumpHeight(double jumpHeight)
    {
        this.jumpHeight = jumpHeight;
    }

    public double getJumpHeight()
    {
        return jumpHeight;
    }

}
