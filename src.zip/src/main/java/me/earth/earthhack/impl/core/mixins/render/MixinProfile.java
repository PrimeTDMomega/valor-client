package me.earth.earthhack.impl.core.mixins.render;

import net.minecraft.client.renderer.GlStateManager;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(GlStateManager.Profile.class)
public abstract class MixinProfile
{


}
