package me.earth.earthhack.impl.commands.packet.arguments;

import net.minecraft.entity.EntityLivingBase;

public class EntityLivingBaseArgument
        extends AbstractEntityArgument<EntityLivingBase>
{
    public EntityLivingBaseArgument()
    {
        super(EntityLivingBase.class);
    }

}
