package me.earth.earthhack.impl.core.ducks.render;

public interface IFramebuffer
{

    int getDepthStencilTexture();

}
