package me.earth.earthhack.api.event.events;

/**
 * {@link StageEvent}.
 */
public enum Stage
{
    PRE,
    POST
}
