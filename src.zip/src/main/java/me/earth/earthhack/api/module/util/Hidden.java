package me.earth.earthhack.api.module.util;

public enum Hidden
{
    Visible,
    Info,
    Hidden
}
